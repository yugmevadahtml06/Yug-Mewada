YUG MEVADA PORTFOLIO — PHOTO-FIXED VERSION

Your portrait is embedded directly inside index.html, so it does not depend on a separate image file path.

PUBLISH WITH NETLIFY:
1. Extract this ZIP.
2. Open the extracted yug_mevada_portfolio folder.
3. Drag the folder (or its contents with index.html at the top level) into https://app.netlify.com/drop.
4. Wait for publishing, then copy the public website URL to share.

You can also double-click index.html to preview locally.
